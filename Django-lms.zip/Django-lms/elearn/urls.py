from django.urls import path, include

from lms.settings import LOGIN_REDIRECT_URL
from . import views
from django.contrib.auth import views as auth_views
from django.conf.urls import url
from django.contrib.auth.decorators import login_required, permission_required
from django.utils.decorators import method_decorator
from elearn.admindecorator import *
from elearn.instdecorator import *
from elearn.learnerdecorator import *

urlpatterns = [

# Shared URLs
path('', views.home, name='home'),
path('about/', views.about, name='about'),
path('contact/', views.contact, name='contact'),
path('lsign/', views.LearnerSignUpView.as_view(), name='lsign'),
path('login_form/', views.login_form, name='login_form'),
path('login/', views.loginView, name='login'),
path('logout/', views.logoutView, name='logout'),
path('admin_search/', views.admin_search, name='search'),
path('instructor_search/', views.instructor_search, name='ins_search'),
path('test/', views.test, name='test'),


# Admin URLs
path('dashboard/',(view_admindashboard_access_only()(views.dashboard)), name='dashboard'),
path('isign/',(view_registerinstructor_access_only()(views.InstructorSignUpView.as_view())), name='isign'),
path('addlearner/',(view_registerlearner_access_only()(views.AdminLearner.as_view())), name='addlearner'),
path('course/',(view_registercourse_access_only()(views.course)), name='course'),
path('apost/', (view_announcement_access_only()(views.AdminCreatePost.as_view())), name='apost'),
path('alpost/',(view_announcement_access_only() (views.AdminListTise.as_view())), name='alpost'),
path('alistalltise/', (view_announcement_access_only()(views.ListAllTise.as_view())), name='alistalltise'),
path('adpost/<int:pk>', (view_announcement_access_only()(views.ADeletePost.as_view())), name='adpost'),
path('aluser/',(view_manageuser_access_only()(views.ListUserView.as_view())), name='aluser'),
path('dynamic_home/',(view_dynamichome_access_only()(views.DynamicHome)), name='dynamic_home'),
path('dynamic_about/',(view_dynamicaboutus_access_only()( views.DynamicAbout)), name='dynamic_about'),
path('aduser/<int:pk>',(view_manageuser_access_only() (views.ADeleteuser.as_view())), name='aduser'),
path('delete_dynamic_home/<int:pk>',(view_dynamichome_access_only() (views.DeleteDynamicHome.as_view())), name='delete_dynamic_home'),
path('delete_dynamic_about/<int:pk>',(view_dynamicaboutus_access_only()(views.DeleteDynamicAboutus.as_view())), name='delete_dynamic_about'),
path('delete_dynamic_contact/<int:pk>',(view_dynamiccontactus_access_only()(views.DeleteDynamicContact.as_view())),name='delete_dynamic_contact'),
path('updateuser/<int:pk>',(view_manageuser_access_only()(views.UpDateuser.as_view())), name='updateuser'),
path('update_dynamic_home/<int:pk>',(view_dynamichome_access_only()(views.UpDateDynamicHome.as_view())),name='update_dynamic_home'),
path('update_dynamic_about/<int:pk>',(view_dynamicaboutus_access_only()(views.UpDateAboutUs.as_view())),name='update_dynamic_about'),
path('update_dynamic_contact/<int:pk>',(view_dynamiccontactus_access_only()(views.UpDateContactUs.as_view())),name='update_dynamic_contact'),
path('create_user_form/',(view_manageuser_access_only()(views.create_user_form)), name='create_user_form'),
path('create_user/',(view_manageuser_access_only()( views.create_user)), name='create_user'),
path('acreate_profile/',(view_manageprofile_access_only()( views.acreate_profile)), name='acreate_profile'),
path('auser_profile/',(view_manageprofile_access_only()( views.auser_profile)), name='auser_profile'),
path('DynamicHome/',(view_dynamichome_access_only()( views.DynamicHome)), name='DynamicHome'),
path('search_courses/',(views.search_courses), name='search-courses'),
path('dynamic_home/',(view_dynamichome_access_only() ( views.dynamichomedata)), name='dynamichomedata'),
path('dynamic_about/',(view_dynamicaboutus_access_only()( views.dynamicaboutdata)), name='dynamic_about'),
path('demo/',(view_dynamichome_access_only()(views.demo)), name='demo'),
path('demo_about/', (view_dynamicaboutus_access_only()(views.demo_about)), name='demo_about'),
path('activate_user/user/<int:user_id>', (view_dynamichome_access_only()(views.activate_user)), name='activate_user'),
path('deactivate_user/user/<int:user_id>',(view_dynamichome_access_only()( views.deactivate_user)), name='deactivate_user'),
path('activate_user_about/user/<int:user_id>', (views.activate_user_about), name='activate_user_about'),
path('deactivate_user_about/user/<int:user_id>',( views.deactivate_user_about), name='deactivate_user_about'),
path('dynamic_contact/',(view_dynamiccontactus_access_only()( views.DynamicContact)), name='dynamic_contact'),
path('dynamic_contact/', (view_dynamiccontactus_access_only()( views.dynamiccontactdata)), name='dynamic_contact'),
path('demo_contact/',(view_dynamiccontactus_access_only()(views.demo_contact)), name='demo_contact'),
path('deactivate_user_contact/user/<int:user_id>',(view_dynamiccontactus_access_only()(views.deactivate_user_contact)), name='deactivate_user_contact'),
path('activate_user_contact/user/<int:user_id>',(view_dynamiccontactus_access_only()(views.activate_user_contact)), name='activate_user_contact'),
path('change_password/',( views.change_password),name='change_password'),
path('AdminUpdateProfile/<int:pk>',(view_manageprofile_access_only()( views.AdminUpdateProfile.as_view())), name='adm_update_profile_new'),
path('StudentCount/',  (view_admindashboard_access_only()(views.StudentCount)), name='StudentCount'),
path('view_courses/',  (view_admindashboard_access_only()(views.view_courses)), name='view_courses'),
path('update_courses/<int:pk>', (view_registercourse_access_only()(views.UpDateCourse.as_view())), name='update_courses'),
path('confirm_delete_course/<int:pk>',(view_registercourse_access_only()(views.DeleteCourse.as_view())), name='confirm_delete_course'),
path('permision/',(view_addpermision_access_only()(views.permision)), name='permision'),
path('addpermision/',(view_addpermision_access_only()(views.addpermision)),name='addpermision'),
path('removepermision/',(views.removepermision),name='removepermision'),
path('removeperm/',(view_removepermision_access_only()(views.removeperm)),name='removeperm'),
path('tag/',(view_addtag_access_only()(views.tag)),name='tag'),
path('addtag/',(view_addtag_access_only()(views.addtag)),name='addtag'),
path('tagview/<str:slug>',(view_addtag_access_only()(views.tagview)),name='tagview'),
path('viewpermision/',(view_removepermision_access_only()(views.viewpermision)),name='viewpermision'),
path('removespecific/',(view_removepermision_access_only()(views.removespecific)),name='removespecific'),
path('viewallcourses/',views.view_all_courses,name='viewallcourses'),
path('approve_course/user/<int:notes_id>',views.approve_course, name='approve_course'),
path('disapprove_course/user/<int:notes_id>',views.disapprove_course, name='disapprove_course'),





# Instructor URLs
path('instructor/',(view_insdashboard_access_only()(views.home_instructor)), name='instructor'),
path('icourse/', (view_instructorregcourse_access_only()(views.icourse)), name='icourse'),
path('update_icourses/<int:pk>', (view_instructorregcourse_access_only()(views.UpDateICourse.as_view())), name='update_icourses'),
path('confirm_delete_icourse/<int:pk>', (view_instructorregcourse_access_only()(views.DeleteICourse.as_view())), name='confirm_delete_icourse'),
path('add_quiz/', (view_managequiz_access_only()(views.QuizCreate)),name='add_quiz'),
path('addcoursequiz/', (view_managequiz_access_only()(views.addcoursequiz)),name='addcoursequiz'),
path('view_icourses/', views.view_icourses, name='view_icourses'),
path('quiz_change/<int:pk>/', (view_managequiz_access_only()(views.QuizUpdateView.as_view())), name='quiz_change'),
path('question_add/<int:pk>', (view_managequiz_access_only()(views.question_add)), name='question_add'),
path('quiz/<int:quiz_pk>/<int:question_pk>/',(view_managequiz_access_only()(views.question_change)), name='question_change'),
path('llist_quiz/', (view_managequiz_access_only()(views.QuizListView.as_view())), name='quiz_change_list'),
path('quiz/<int:quiz_pk>/question/<int:question_pk>/delete/', (view_managequiz_access_only()(views.QuestionDeleteView.as_view())), name='question_delete'),
path('quiz/<int:pk>/results/', (view_managequiz_access_only()(views.QuizResultsView.as_view())), name='quiz_results'),
path('ipost/', (view_instructorannouncement_access_only()(views.CreatePost.as_view())), name='ipost'),
path('llchat/', (view_instructorannouncement_access_only()(views.TiseList.as_view())), name='llchat'),
path('user_profile/', (view_insmanageprofile_access_only()(views.user_profile)), name='user_profile'),
path('create_profile/', (view_insmanageprofile_access_only()(views.create_profile)), name='create_profile'),
path('tutorial/', (view_managetutorial_access_only()(views.tutorial)), name='tutorial'),
path('post/',(view_managetutorial_access_only()(views.publish_tutorial)),name='publish_tutorial'),
path('itutorial/',(view_managetutorial_access_only()(views.itutorial)),name='itutorial'),
path('itutorials/<int:pk>/', (view_managetutorial_access_only()(views.ITutorialDetail.as_view())), name = "itutorial-detail"),
path('listnotes/', (view_managenotes_access_only()(views.LNotesList.as_view())), name='lnotes'),
path('iadd_notes/', (view_managenotes_access_only()(views.iadd_notes)), name='iadd_notes'),
path('publish_notes/', (view_managenotes_access_only()(views.publish_notes)), name='publish_notes'),
path('update_file/<int:pk>', (view_managenotes_access_only()(views.update_file)), name='update_file'),
path('deletetutorial/<int:pk>',(view_managenotes_access_only()(views.delete_tutorial.as_view())), name='deletetutorial'),
path('updatetutorial/<int:pk>',(view_managetutorial_access_only()(views.UpDateTutorial.as_view())), name='updatetutorial'),
path('delete_file/<int:pk>',(view_managenotes_access_only()(views.delete_notes.as_view())), name='delete_file'),
path('InsUpdateProfile/<int:pk>', (view_insmanageprofile_access_only()(views.InsUpdateProfile.as_view())), name='ins_update_profile_new'),
path('deletequiz/<int:pk>',(view_managequiz_access_only()(views.deletequiz.as_view())), name='deletequiz'),
# path('instchart/', views.instchart, name='instchart'),



# Learner URl's
path('learner/',(view_learnerdashboard_access_only()(views.home_learner)),name='learner'),
path('ltutorial/',(view_readtutorial_access_only()(views.ltutorial)),name='ltutorial'),
# path('llistnotes/', views.LLNotesList.as_view(), name='llnotes'),
path('llistnotes/', (view_readnotes_access_only()(views.LLNotesList)), name='llnotes'),
path('learner_course/', (view_course_access_only()(views.LearnerCourse.as_view())), name='learner_course'),
path('ilchat/', (view_learnerannouncement_access_only()(views.ITiseList.as_view())), name='ilchat'),
path('luser_profile/', (view_learnermanageprofile_access_only()(views.luser_profile)), name='luser_profile'),
path('lcreate_profile/', (view_learnermanageprofile_access_only()(views.lcreate_profile)), name='lcreate_profile'),
path('tutorials/<int:pk>/', (view_readtutorial_access_only()(views.LTutorialDetail.as_view())), name = "tutorial-detail"),
path('interests/', (view_readtutorial_access_only()(views.LearnerInterestsView.as_view())), name='interests'),
path('learner_quiz/', (view_takequiz_access_only()(views.LQuizListView)), name='lquiz_list'),
path('taken/', (view_takequiz_access_only()(views.TakenQuizListView.as_view())), name='taken_quiz_list'),
path('quiz/<int:pk>/', (view_takequiz_access_only()(views.take_quiz)), name='take_quiz'),
path('update_profile_new/<int:pk>/', (view_learnermanageprofile_access_only()(views.UpDateProfile.as_view())), name='update_profile_new'),
path('showregcourse/',(view_course_access_only()(views.showregcourse)),name='showregcourse'),
path('delete_registered_course/<int:pk>',(view_course_access_only()(views.delete_registered_course.as_view())), name='delete_registered_course'),
path('EnrollChart/', (view_learnerdashboard_access_only()(views.EnrollChart)), name='EnrollChart'),
path('enrolment/<int:pk>/',(view_learnerdashboard_access_only()(views.enrolment)),name='enrolment'),
]
