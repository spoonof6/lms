from functools import wraps
from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponse


#view_learnerdashboard
def view_learnerdashboard_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_learnerdashboard")):
            return True
    return False


def view_learnerdashboard_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_learnerdashboard_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator

#view_course
def view_course_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_course")):
            return True
    return False


def view_course_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_course_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_takequiz
def view_takequiz_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_takequiz")):
            return True
    return False


def view_takequiz_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_takequiz_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_readtutorial
def view_readtutorial_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_readtutorial")):
            return True
    return False


def view_readtutorial_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_readtutorial_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator

#view_readnotes
def view_readnotes_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_readnotes")):
            return True
    return False


def view_readnotes_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_readnotes_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_learnerannouncement
def view_learnerannouncement_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_learnerannouncement")):
            return True
    return False


def view_learnerannouncement_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_learnerannouncement_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_learnermanageprofile
def view_learnermanageprofile_test_function(user):
    if user.is_learner:
        if (user.has_perm("elearn.view_learnermanageprofile")):
            return True
    return False


def view_learnermanageprofile_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_learnermanageprofile_test_function(request.user):
                return HttpResponse("You are not a Learner and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator