from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.forms.utils import ValidationError
from django import forms
from elearn.models import (
    Course,
    Answer,
    User,
    Learner,
    LearnerAnswer,
    Announcement,
    Question,
    Home,
)
from django.forms import ModelForm
from .models import *
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Fieldset, Submit


class InstructorSignUpForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User

    def __init__(self, *args, **kwargs):
        super(InstructorSignUpForm, self).__init__(*args, **kwargs)

        for fieldname in ["username", "password1", "password2"]:
            self.fields[fieldname].help_text = None

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_instructor = True
        if commit:
            user.save()
        return user


class LearnerSignUpForm(UserCreationForm):
    # interests = forms.ModelMultipleChoiceField(
    #     queryset=Course.objects.all(),
    #     widget=forms.CheckboxSelectMultiple,
    #     required=True
    # )

    class Meta(UserCreationForm.Meta):
        model = User

    def __init__(self, *args, **kwargs):
        super(LearnerSignUpForm, self).__init__(*args, **kwargs)

        for fieldname in ["username", "password1", "password2"]:
            self.fields[fieldname].help_text = None

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_learner = True
        user.save()
        learner = Learner.objects.create(user=user)
        # learner.interests.add(*self.cleaned_data.get('interests'))
        return user


class PostForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ("content",)


class DynamicHomeForm(forms.ModelForm):
    class Meta:
        model = Home
        fields = [
            "upper_title",
            "bottom_title",
            "detail_title",
            "title_image",
            "detail_image",
            "director_desc",
            "director_name",
        ]


class LearnerInterestsForm(forms.ModelForm):
    class Meta:
        model = Learner
        fields = ("interests",)
        widgets = {"interests": forms.CheckboxSelectMultiple}


class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ("text",)


class BaseAnswerInlineFormSet(forms.BaseInlineFormSet):
    def clean(self):
        super().clean()

        has_one_correct_answer = False
        for form in self.forms:
            if not form.cleaned_data.get("DELETE", False):
                if form.cleaned_data.get("is_correct", False):
                    has_one_correct_answer = True
                    break
        if not has_one_correct_answer:
            raise ValidationError(
                "Mark at least one answer as correct.", code="no_correct_answer"
            )


class TakeQuizForm(forms.ModelForm):
    answer = forms.ModelChoiceField(
        queryset=Answer.objects.none(),
        widget=forms.RadioSelect(),
        required=True,
        empty_label=None,
    )

    class Meta:
        model = LearnerAnswer
        fields = ("answer",)

    def __init__(self, *args, **kwargs):
        question = kwargs.pop("question")
        super().__init__(*args, **kwargs)
        self.fields["answer"].queryset = question.answers.order_by("text")
