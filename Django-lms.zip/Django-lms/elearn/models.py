from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.html import escape, mark_safe
from embed_video.fields import EmbedVideoField
from django.core.validators import FileExtensionValidator


class User(AbstractUser):
    is_learner = models.BooleanField(default=False)
    is_instructor = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)


class Home(models.Model):
    upper_title = models.CharField(max_length=255, blank=True)
    bottom_title = models.CharField(max_length=255, blank=True)
    detail_title = models.CharField(max_length=255, blank=True)
    title_image = models.ImageField(upload_to="", default="bisag1.jpg")
    detail_image = models.ImageField(upload_to="", default="bisag1.jpg")
    director_desc = models.CharField(max_length=255, blank=True)
    director_name = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=False)


class AboutUs(models.Model):
    about_title = models.CharField(max_length=255, blank=True)
    aboutus_content = models.TextField(max_length=1255, blank=True)
    image = models.ImageField(upload_to="", default="no-img.jpg", blank=True)
    is_active = models.BooleanField(default=False)


class ContactUs(models.Model):
    name1 = models.CharField(max_length=15, blank=True)
    name2 = models.CharField(max_length=15, blank=True)
    name3 = models.CharField(max_length=15, blank=True)
    name4 = models.CharField(max_length=15, blank=True)
    number1 = models.IntegerField(blank=True)
    number2 = models.IntegerField(blank=True)
    number3 = models.IntegerField(blank=True)
    number4 = models.IntegerField(blank=True)
    is_active = models.BooleanField(default=False)


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to="", default="no-img.jpg", blank=True)
    first_name = models.CharField(max_length=255, default="")
    last_name = models.CharField(max_length=255, default="")
    email = models.EmailField(default="none@email.com")
    phonenumber = models.CharField(max_length=255, blank=True, null=True)
    birth_date = models.DateField(default="1975-12-12")
    bio = models.TextField(default="")
    city = models.CharField(max_length=255, default="")
    state = models.CharField(max_length=255, default="")
    country = models.CharField(max_length=255, default="")
    favorite_animal = models.CharField(max_length=255, default="")
    hobby = models.CharField(max_length=255, default="")

    def __str__(self):
        return self.user.username


class Announcement(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    posted_at = models.DateTimeField(auto_now=True, null=True)

    def __str__(self):
        return str(self.content)


class Course(models.Model):
    name = models.CharField(max_length=30, unique=True, blank=False, null=False)
    instructor_name = models.ForeignKey(
        User, on_delete=models.CASCADE, null=True, blank=True
    )

    def __str__(self):
        return self.name

    def get_html_badge(self):
        name = escape(self.name)
        html = (
            '<span class="badge badge-primary" style="background-color: %s">%s</span>'
            % (name, name)
        )
        return mark_safe(html)


class Tutorial(models.Model):
    title = models.CharField(max_length=50)
    content = models.TextField()
    thumb = models.ImageField(upload_to="", null=True, blank=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    video = EmbedVideoField(blank=True, null=True)


class Notes(models.Model):
    title = models.CharField(max_length=500)
    video = models.FileField(
        upload_to="videos_uploaded/%y",
        blank=True,
        validators=[
            FileExtensionValidator(
                allowed_extensions=["MOV", "avi", "mp4", "webm", "mkv"]
            )
        ],
    )
    file = models.FileField(upload_to="documents/%m%Y", null=True, blank=True)
    cover = models.ImageField(upload_to="", null=True, blank=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="notes")
    user = models.ForeignKey(User, on_delete=models.CASCADE,related_name="notes")
    is_approved = models.BooleanField(default=False)
    def __str__(self):
        return self.title

    def delete(self, *args, **kwargs):
        self.file.delete()
        self.cover.delete()
        super().delete(*args, **kwargs)


class Quiz(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="quizzes")
    name = models.CharField(max_length=255)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="quizzes")

    def __str__(self):
        return self.name


class Question(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="questions")
    text = models.CharField("Question", max_length=255)

    def __str__(self):
        return self.text


class Answer(models.Model):
    question = models.ForeignKey(
        Question, on_delete=models.CASCADE, related_name="answers"
    )
    text = models.CharField("Answer", max_length=255)
    is_correct = models.BooleanField("Correct answer", default=False)

    def __str__(self):
        return self.text


class Learner(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    quizzes = models.ManyToManyField(Quiz, through="TakenQuiz")
    interests = models.ManyToManyField(Course, related_name="interested_learners")

    def get_unanswered_questions(self, quiz):
        answered_questions = self.quiz_answers.filter(
            answer__question__quiz=quiz
        ).values_list("answer__question__pk", flat=True)
        questions = quiz.questions.exclude(pk__in=answered_questions).order_by("text")
        return questions

    def __str__(self):
        return self.user.username


class Instructor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    interest = models.ManyToManyField(Course, related_name="more_locations")


class TakenQuiz(models.Model):
    learner = models.ForeignKey(
        Learner, on_delete=models.CASCADE, related_name="taken_quizzes"
    )
    quiz = models.ForeignKey(
        Quiz, on_delete=models.CASCADE, related_name="taken_quizzes"
    )
    score = models.FloatField()
    date = models.DateTimeField(auto_now_add=True)


class LearnerAnswer(models.Model):
    student = models.ForeignKey(
        Learner, on_delete=models.CASCADE, related_name="quiz_answers"
    )
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, related_name="+")


class Enrollment(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    coursename = models.ForeignKey(
        Course, on_delete=models.CASCADE, related_name="enrollment_course"
    )

    def __str__(self):
        return "%s %s" % (self.student, self.coursename)


class Tag(models.Model):
    title = models.CharField(max_length=500)
    slug = models.SlugField(unique=True)

    class Meta:
        permissions = (
            ("view_slug", "Admin Create slug"),
            ("view_admindashboard", "Admin admindashboard"),
            ("view_registerinstructor", "Admin Register Instructor"),
            ("view_registerlearner", "Admin Register Learner"),
            ("view_registercourse", "Admin Register Course"),
            ("view_announcement", "Admin Annoucement"),
            ("view_manageuser", "Admin Manage User"),
            ("view_manageprofile", "Admin Manage Profile"),
            ("view_dynamichome", "Admin Dynamic Home"),
            ("view_dynamicaboutus", "Admin Dynamic AboutUs"),
            ("view_dynamiccontactus", "Admin Dynamic ContactUs"),
            ("view_createrole", "Admin Create Role"),
            ("view_addtag", "Admin Add Tag"),
            ("view_addpermision", "Admin Add Permision"),
            ("view_removepermision", "Admin Remove Permision"),
            ##instructor permision
            ("view_insdashboard", "Instructor dashboard"),
            ("view_instructorregcourse", "Instructor Register Course"),
            ("view_managequiz", "Instructor Manage Quiz"),
            ("view_managetutorial", "Instructor Manage Tutorial"),
            ("view_managenotes", "Instructor Manage Notes"),
            ("view_instructorannouncement", "Instructor Announcement"),
            ("view_insmanageprofile", "Instructor ManageProfile"),
            ##learner permision
            ("view_learnerdashboard", "Learner dashboard"),
            ("view_course", "Learner Course"),
            ("view_takequiz", "Learner Quiz"),
            ("view_readtutorial", "Learner Read Tutorial"),
            ("view_readnotes", "Learner Read Notes"),
            ("view_learnerannouncement", "Learner Announcement"),
            ("view_learnermanageprofile", "Learner ManageProfile"),
        )

# class Post(models.Model):
#     writer = models.ForeignKey(User, on_delete = models.SET_NULL, null = True, blank = True)
#     title = models.CharField(max_length=500)
#     image  = models.ImageField(upload_to='img', default='img/default.jpg')
#     body = RichTextField()
#     slug = models.SlugField(unique=True)
#     post_id = models.UUIDField(default = uuid.uuid4, unique=True, editable = False, primary_key = True)
#     tag = models.ForeignKey('Tag', on_delete = models.SET_NULL, blank = True, null = True)
#     created = models.DateTimeField(auto_now_add = True)
#     modified = models.DateTimeField(auto_now = True)

#     @property
#     def imageUrl(self):
#         try:
#             url = self.image.url
#         except:
#             url = ''
#         return url

#     class Meta:
#         ordering = ['-created']

#     def __str__(self):
#         return self.title