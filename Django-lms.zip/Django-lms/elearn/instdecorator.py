from functools import wraps
from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponse

#view_insdashboard
def view_insdashboard_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_insdashboard")):
            return True
    return False


def view_insdashboard_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_insdashboard_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_instructorregcourse
def view_instructorregcourse_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_instructorregcourse")):
            return True
    return False


def view_instructorregcourse_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_instructorregcourse_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_managequiz
def view_managequiz_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_managequiz")):
            return True
    return False


def view_managequiz_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_managequiz_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_managetutorial
def view_managetutorial_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_managetutorial")):
            return True
    return False


def view_managetutorial_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_managetutorial_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_managenotes
def view_managenotes_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_managenotes")):
            return True
    return False


def view_managenotes_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_managenotes_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_instructorannouncement
def view_instructorannouncement_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_instructorannouncement")):
            return True
    return False


def view_instructorannouncement_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_instructorannouncement_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_insmanageprofile
def view_insmanageprofile_test_function(user):
    if user.is_instructor:
        if (user.has_perm("elearn.view_insmanageprofile")):
            return True
    return False


def view_insmanageprofile_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_insmanageprofile_test_function(request.user):
                return HttpResponse("You are not a Instructor and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator