from audioop import avg
from multiprocessing import context
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib import messages
from django.contrib.auth import logout
from django.urls import reverse_lazy
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.views.generic import ListView, DetailView, CreateView
from django.views.generic.edit import CreateView, DeleteView, UpdateView
from elearn.forms import (
    TakeQuizForm,
    LearnerSignUpForm,
    InstructorSignUpForm,
    PostForm,
    QuestionForm,
    BaseAnswerInlineFormSet,
    LearnerInterestsForm,
    DynamicHomeForm,
)
from django.utils import timezone
from django.contrib import auth

from lms.settings import LOGIN_REDIRECT_URL
from .models import (
    Course,
    Announcement,
    Home,
    User,
    TakenQuiz,
    Profile,
    Quiz,
    Question,
    Answer,
    Tutorial,
    Notes,
    Learner,
    AboutUs,
    ContactUs,
)
from django.db.models import Count, Avg
from django.db import transaction
from django.forms import inlineformset_factory
from django.contrib.auth.hashers import make_password
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from .forms import *
from django.contrib.auth.decorators import login_required, permission_required
from django.http import Http404, HttpResponse, HttpResponseForbidden
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin, PermissionRequiredMixin
from django.utils.decorators import method_decorator
from django.contrib.auth.models import User, Permission
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model
import pandas as pd
User = get_user_model()


# Shared Views

all_instructor = list(User.objects.filter(is_instructor=True))

single_user_instructor = User.objects.filter(is_instructor=True).values_list('id').first()

    
instructorperm = Permission.objects.filter(user=single_user_instructor)



for perm in instructorperm:
    for iuser in all_instructor:
        iuser.user_permissions.add(perm)




def home(request):
    list = Home.objects.all()
    context = {"list": list}
    return render(request, "home.html", context)


def about(request):
    data = AboutUs.objects.all()
    context = {"data": data}
    return render(request, "about.html", context)


def services(request):
    return render(request, "service.html")


def contact(request):
    data = ContactUs.objects.all()
    context = {"data": data}
    return render(request, "contact.html", context)


def login_form(request):
    return render(request, "login.html")

def admin_search(request):
    query = request.GET["query"]
    announcement = Announcement.objects.filter(content__icontains=query)
    context = {"announcement": announcement}
    return render(request, "dashboard/admin/search.html", context)


def instructor_search(request):
    query_inst = request.GET["query_inst"]
    announcement = Announcement.objects.filter(content__icontains=query_inst)
    quiz = Quiz.objects.filter(name__icontains=query_inst)
    tutorial = Tutorial.objects.filter(title__icontains=query_inst)
    notes = Notes.objects.filter(title__icontains=query_inst)
    context = {
        "announcement": announcement,
        "quiz": quiz,
        "tutorial": tutorial,
        "notes": notes,
    }
    return render(request, "dashboard/instructor/ins_search.html", context)


def logoutView(request):
    logout(request)
    return redirect("home")


def loginView(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_active:
            auth.login(request, user)
            if user.is_admin or user.is_superuser:
                all_admin = list(User.objects.filter(is_admin=True))
                
                single_user_admin = User.objects.filter(is_admin=True).values_list('id').first()

                instructorperm = Permission.objects.filter(user=single_user_admin)
                
                for perm in instructorperm:
                    for iuser in all_admin:
                        iuser.user_permissions.add(perm)

                return redirect("dashboard")
            elif user.is_instructor:
                all_instructor = list(User.objects.filter(is_instructor=True))
                single_user_instructor = User.objects.filter(is_instructor=True).values_list('id').first()
                instructorperm = Permission.objects.filter(user=single_user_instructor)
                for perm in instructorperm:
                    for iuser in all_instructor:
                        iuser.user_permissions.add(perm)

                return redirect("instructor")
            elif user.is_learner:
                all_learner = list(User.objects.filter(is_learner=True))
   
                single_user_learner = User.objects.filter(is_learner=True).values_list('id').first()

                instructorperm = Permission.objects.filter(user=single_user_learner)
            
                for perm in instructorperm:
                    for iuser in all_learner:
                        iuser.user_permissions.add(perm)
                        
                return redirect("learner")
            else:
                return redirect("login_form")
        else:
            messages.info(request, "Invalid Username or Password")
            return redirect("login_form")


# Learner Views


class LearnerSignUpView(CreateView):
    model = User
    form_class = LearnerSignUpForm
    template_name = "signup_form.html"

    def get_context_data(self, **kwargs):
        kwargs["user_type"] = "learner"
        return super().get_context_data(**kwargs)

    def fom_valid(self, form):
        user = form.save()
        login(self.request, user)
        # return redirect('learner')
        return redirect("home")


# Admin Views

def search_courses(request):
    if request.method == "POST":
        searched = request.POST["searched"]
        courses = Course.objects.filter(name__contains=searched)
        return render(
            request,
            "dashboard/admin/home.html",
            {"searched": searched, "courses": courses},
        )
    else:
        return render(request, "dashboard/admin/home.html")

def dashboard(request):
    tags = Tag.objects.all()
    learner = User.objects.filter(is_learner=True).count()
    instructor = User.objects.filter(is_instructor=True).count()
    adm = User.objects.filter(is_admin=True).count()
    course = Course.objects.all().count()
    users = User.objects.all().count()
    notes = Notes.objects.filter(is_approved = True).count()
    cpa = Permission.objects.all().count()
    dh = Home.objects.all().count()
    da = AboutUs.objects.all().count()
    dc = ContactUs.objects.all().count()


    queryset = list(
        Course.objects.filter().values("id", "name")
        )
    listx = []
    listz = []
    listy = []
    listi = []

    for i in queryset:
        x = i["id"]
        z = i["name"]
        listx.append(x)
        listz.append(z)
    for j in listx:
        y = Enrollment.objects.filter(coursename_id=j).count()
        listy.append(y)
    for i in listx:
        i = Notes.objects.filter(course_id = i).count()
        listi.append(i)
    context = {
        "learner": learner,
        "course": course,
        "instructor": instructor,
        "users": users,
        'tags':tags,
        'notes' : notes,
        'cpa':cpa,
        'adm':adm,
        "listz": listz,
        "listx": listx,
        "listy": listy,
        "listi" : listi,
        "dh":dh,
        "da":da,
        "dc":dc
    }


    return render(request, "dashboard/admin/home.html", context)

class InstructorSignUpView(CreateView, LoginRequiredMixin):
    login_url = LOGIN_REDIRECT_URL
    model = User
    form_class = InstructorSignUpForm
    template_name = "dashboard/admin/signup_form.html"

   

    def get_context_data(self, **kwargs):
        kwargs["user_type"] = "instructor"
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        messages.success(self.request, "Instructor Was Added Successfully")
        return redirect("isign")

        



def DynamicHome(request):
    if request.method == "POST":
        upper_title = request.POST["upper_title"]
        bottom_title = request.POST["bottom_title"]
        detail_title = request.POST["detail_title"]
        title_image = request.FILES["title_image"]
        detail_image = request.FILES["detail_image"]
        director_desc = request.POST["director_desc"]
        director_name = request.POST["director_name"]


        Home.objects.create(
            upper_title=upper_title,
            bottom_title=bottom_title,
            detail_title=detail_title,
            title_image=title_image,
            detail_image=detail_image,
            director_desc=director_desc,
            director_name=director_name,
        )
        messages.success(request, "Your Dynamic Home Was Created Successfully")
        return redirect("demo")
    else:
        list = Home.objects.all()
        context = {"list": list}
        return render(request, "dashboard/admin/dynamic_home.html", context)


def dynamichomedata(request):
    dhd = Home.objects.all()
    context = {"dhd": dhd}
    return render(request, "dashboard/admin/dynamic_home.html", context)


def demo(request):
    dhd = Home.objects.all()
    context = {"dhd": dhd}
    return render(request, "dashboard/admin/demo.html", context)


def demodetail(request):
    if request.method == "POST":
        id = request.get("id")
        return HttpResponseRedirect("success")


def deactivate_user(request, user_id):
    user = Home.objects.get(pk=user_id)
    user.is_active = False
    user.save()
    # messages.success(request, "User account has been successfully deactivated!")
    return render(request, "dashboard/admin/dynamic_home.html")


def activate_user(request, user_id):
    allusers = Home.objects.all()
    for i in allusers:
        i.is_active = False
        i.save()
    user = Home.objects.get(pk=user_id)
    user.is_active = True
    user.save()
    # messages.success(request, "User account has been successfully activated!")
    return render(request, "dashboard/admin/dynamic_home.html")


# activate deactivate functionality
def DynamicAbout(request):
    if request.method == "POST":
        about_title = request.POST["about_title"]
        aboutus_content = request.POST["aboutus_content"]
        image = request.FILES["image"]
        # current_user = request.user
        # user_id = current_user.id
        # print(user_id)

        AboutUs.objects.create(
            about_title=about_title, aboutus_content=aboutus_content, image=image
        )
        # messages.success(request, 'Your Dynamic Home Was Created Successfully')
        return redirect("dynamic_about")
    else:
        list = AboutUs.objects.all()
        context = {"list": list}
        return render(request, "dashboard/admin/dynamic_about.html", context)


def dynamicaboutdata(request):
    da = AboutUs.objects.all()
    context = {"da": da}
    return render(request, "dashboard/admin/dynamic_about.html", context)


def demo_about(request):
    dt = AboutUs.objects.all()
    context = {"dt": dt}
    return render(request, "dashboard/admin/demo_about.html", context)


def about_details(request):
    if request.method == "POST":
        id = request.get("id")
        return HttpResponseRedirect("success")


def deactivate_user_about(request, user_id):
    user = AboutUs.objects.get(pk=user_id)
    user.is_active = False
    user.save()
    # messages.success(request, "User account has been successfully deactivated!")
    return redirect("dynamic_about")
    # return render(request,'dashboard/admin/dynamic_about.html')


def activate_user_about(request, user_id):
    allusers = AboutUs.objects.all()
    for i in allusers:
        i.is_active = False
        i.save()
    user = AboutUs.objects.get(pk=user_id)
    user.is_active = True
    user.save()
    # messages.success(request, "User account has been successfully activated!")
    return redirect("dynamic_about")
    # return render(request,'dashboard/admin/dynamic_about.html')


def DynamicContact(request):
    if request.method == "POST":
        name1 = request.POST["name1"]
        name2 = request.POST["name2"]
        name3 = request.POST["name3"]
        name4 = request.POST["name4"]
        number1 = request.POST["number1"]
        number2 = request.POST["number2"]
        number3 = request.POST["number3"]
        number4 = request.POST["number4"]
        # current_user = request.user
        # user_id = current_user.id
        # print(user_id)

        ContactUs.objects.create(
            name1=name1,
            name2=name2,
            name3=name3,
            name4=name4,
            number1=number1,
            number2=number2,
            number3=number3,
            number4=number4,
        )
        # messages.success(request, 'Your Dynamic Home Was Created Successfully')
        return redirect("dynamic_contact")
    else:
        list = ContactUs.objects.all()
        context = {"list": list}
        return render(request, "dashboard/admin/dynamic_contact.html", context)


def demo_contact(request):
    data = ContactUs.objects.all()
    context = {"data": data}
    return render(request, "dashboard/admin/demo_contact.html", context)


def dynamiccontactdata(request):
    dc = ContactUs.objects.all()
    context = {"dc": dc}
    return render(request, "dashboard/admin/demo_contact.html", context)


def contact_details(request):
    if request.method == "POST":
        id = request.get("id")
        return HttpResponseRedirect("success")


def deactivate_user_contact(request, user_id):
    user = ContactUs.objects.get(pk=user_id)
    user.is_active = False
    user.save()
    # messages.success(request, "User account has been successfully deactivated!")
    return redirect("demo_contact")
    # return render(request,'dashboard/admin/dynamic_contact.html')


def activate_user_contact(request, user_id):
    allusers = ContactUs.objects.all()
    for i in allusers:
        i.is_active = False
        i.save()
    user = ContactUs.objects.get(pk=user_id)
    user.is_active = True
    user.save()
    # messages.success(request, "User account has been successfully activated!")
    return redirect("demo_contact")
    # return render(request,'dashboard/admin/dynamic_contact.html')


class ListUserView(LoginRequiredMixin, ListView):
    model = User
    template_name = "dashboard/admin/list_users.html"
    context_object_name = "users"
    paginated_by = 10
    def get_queryset(self):
        return User.objects.order_by("-id")


    # def dispatch(self, request, *args, **kwargs):
    #     if not request.user.has_perm():
    #         return HttpResponseForbidden()
    #     return super(ListUserView, self).dispatch(request, *args, **kwargs)



class ListHomeView(LoginRequiredMixin, ListView):
    model = Home
    template_name = "dashboard/admin/dynamic_home.html"
    context_object_name = "dynamic_view"
    paginated_by = 10

    def get_queryset(self):
        return Home.objects.order_by("-id")


class AdminLearner(CreateView):
    model = User
    form_class = LearnerSignUpForm
    template_name = "dashboard/admin/learner_signup_form.html"

    def get_context_data(self, **kwargs):
        kwargs["user_type"] = "learner"
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        messages.success(self.request, "Learner Was Added Successfully")
        return redirect("addlearner")


def course(request):
    if request.method == "POST":
        name = request.POST["name"]
        a = Course(name=name)
        a.save()
        messages.success(request, "New Course Was Registed Successfully")
        return redirect("course")
    else:
        return render(request, "dashboard/admin/course.html")


def view_courses(request):
    dhd = Course.objects.all()
    context = {"dhd": dhd}
    return render(request, "dashboard/admin/course_detail.html", context)


class DeleteCourse(SuccessMessageMixin, DeleteView):
    model = Course
    template_name = "dashboard/admin/confirm_delete_course.html"
    success_url = reverse_lazy("view_courses")
    success_message = "Course Was Deleted Successfully"


class UpDateCourse(SuccessMessageMixin, UpdateView):
    model = Course
    fields = [
        "name",
    ]

    template_name = "dashboard/admin/course_update.html"
    success_url = reverse_lazy("course")
    success_message = " Course is Updated Successfully"


class AdminCreatePost(CreateView):
    model = Announcement
    form_class = PostForm
    template_name = "dashboard/admin/post_form.html"
    success_url = reverse_lazy("alpost")

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.user = self.request.user
        self.object.save()
        return super().form_valid(form)


class AdminListTise(LoginRequiredMixin, ListView):
    model = Announcement
    template_name = "dashboard/admin/tise_list.html"

    def get_queryset(self):
        return Announcement.objects.filter(posted_at__lt=timezone.now()).order_by(
            "posted_at"
        )


class ListAllTise(LoginRequiredMixin, ListView):
    model = Announcement
    template_name = "dashboard/admin/list_tises.html"
    context_object_name = "tises"
    paginated_by = 10

    def get_queryset(self):
        return Announcement.objects.order_by("-id")


class ADeletePost(SuccessMessageMixin, DeleteView):
    model = Announcement
    template_name = "dashboard/admin/confirm_delete.html"
    success_url = reverse_lazy("alistalltise")
    success_message = "Announcement Was Deleted Successfully"


class ListUserView(LoginRequiredMixin, ListView):
    model = User
    template_name = "dashboard/admin/list_users.html"
    context_object_name = "users"
    paginated_by = 10

    def get_queryset(self):
        return User.objects.order_by("-id")


class ADeleteuser(SuccessMessageMixin, DeleteView):
    model = User
    template_name = "dashboard/admin/confirm_delete2.html"
    success_url = reverse_lazy("aluser")
    success_message = "User Was Deleted Successfully"


class DeleteDynamicHome(SuccessMessageMixin, DeleteView):
    model = Home
    template_name = "dashboard/admin/confirm_delete_home.html"
    success_url = reverse_lazy("demo")
    success_message = "Data Was Deleted Successfully"


class DeleteDynamicAboutus(SuccessMessageMixin, DeleteView):
    model = AboutUs
    template_name = "dashboard/admin/confirm_delete_about.html"
    success_url = reverse_lazy("demo_about")
    success_message = "Data Was Deleted Successfully"


class DeleteDynamicContact(SuccessMessageMixin, DeleteView):
    model = ContactUs
    template_name = "dashboard/admin/confirm_delete_contact.html"
    success_url = reverse_lazy("demo_contact")
    success_message = "Data Was Deleted Successfully"


class UpDateuser(SuccessMessageMixin, UpdateView):
    model = User
    fields = [
        "is_learner",
        "is_instructor",
        "is_admin",
        "username",
    ]
    template_name = "dashboard/admin/confirm_update.html"
    success_url = reverse_lazy("aluser")
    success_message = " User is Updated Successfully"


class UpDateDynamicHome(SuccessMessageMixin, UpdateView):
    form_class = DynamicHomeForm
    model = Home

    template_name = "dashboard/admin/confirm_dynamichomeupdate.html"
    success_url = reverse_lazy("demo")
    success_message = " Dynamic Details are Updated Successfully"


class UpDateAboutUs(SuccessMessageMixin, UpdateView):
    model = AboutUs
    fields = [
        "about_title",
        "aboutus_content",
        "image",
    ]

    template_name = "dashboard/admin/confirm_aboutusupdate.html"
    success_url = reverse_lazy("demo_about")
    success_message = " About Us is Updated Successfully"


class UpDateContactUs(SuccessMessageMixin, UpdateView):
    model = ContactUs
    fields = [
        "name1",
        "name2",
        "name3",
        "name4",
        "number1",
        "number2",
        "number3",
        "number4",
    ]

    template_name = "dashboard/admin/confirm_contactupdate.html"
    success_url = reverse_lazy("demo_contact")
    success_message = " ContactUs is Updated Successfully"


def change_password(request):
    if request.method == "POST":
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, "Your password was successfully updated!")
            return redirect("change_password")
        else:
            messages.warning(request, "Your password does not match !!")
            return render(
                request, "dashboard/admin/change_password.html", {"form": form}
            )
    else:
        form = PasswordChangeForm(request.user)
        return render(request, "dashboard/admin/change_password.html", {"form": form})


def create_user_form(request):
    return render(request, "dashboard/admin/add_user.html")


def create_user_form(request):
    return render(request, "dashboard/admin/add_user.html")


def create_user(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        password = make_password(password)

        a = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            password=password,
            email=email,
            is_admin=True,
        )
        a.save()
        messages.success(request, "Admin Was Created Successfully")
        return redirect("aluser")
    else:
        messages.error(request, "Admin Was Not Created Successfully")
        return redirect("create_user_form")


def acreate_profile(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        birth_date = request.POST["birth_date"]
        bio = request.POST["bio"]
        phonenumber = request.POST["phonenumber"]
        city = request.POST["city"]
        country = request.POST["country"]
        avatar = request.FILES["avatar"]
        # hobby = request.POST['hobby']
        current_user = request.user
        user_id = current_user.id

        Profile.objects.filter(id=user_id).create(
            user_id=user_id,
            phonenumber=phonenumber,
            first_name=first_name,
            last_name=last_name,
            bio=bio,
            birth_date=birth_date,
            avatar=avatar,
            city=city,
            country=country,
        )
        messages.success(request, "Your Profile Was Created Successfully")
        return redirect("auser_profile")
    else:
        current_user = request.user
        user_id = current_user.id
        users = Profile.objects.filter(user_id=user_id)
        users = {"users": users}
        return render(request, "dashboard/admin/create_profile.html", users)


def auser_profile(request):
    current_user = request.user
    user_id = current_user.id
    users = Profile.objects.filter(user_id=user_id)
    users = {"users": users}
    return render(request, "dashboard/admin/user_profile.html", users)






# Instructor Views


def home_instructor(request):
    learner = User.objects.filter(is_learner=True).count()
    instructor = User.objects.filter(is_instructor=True).count()
    course = Course.objects.all().count()
    users = User.objects.all().count()
    user_id = request.user.id
    queryset = list(
        Course.objects.filter(instructor_name_id=user_id).values("id", "name")
    )

    listx = []
    listz = []
    listy = []

    for i in queryset:
        x = i["id"]
        z = i["name"]
        listx.append(x)
        listz.append(z)

    for j in listx:
        y = Enrollment.objects.filter(coursename_id=j).count()
        listy.append(y)

    context = {
        "listz": listz,
        "listx": listx,
        "listy": listy,
        "learner": learner,
        "course": course,
        "instructor": instructor,
        "users": users,
    }

    return render(request, "dashboard/instructor/home.html", context)

def icourse(request):
    if request.method == "POST":
        name = request.POST["name"]
        instructor_name = request.user

        a = Course(name=name, instructor_name=instructor_name)
        a.save()
        messages.success(request, "New Course Was Registed Successfully")
        return redirect("icourse")
    else:
        return render(request, "dashboard/instructor/icourse.html")


def view_icourses(request):
    dhd = Course.objects.filter(instructor_name_id=request.user.id)
    context = {"dhd": dhd}
    return render(request, "dashboard/instructor/icourse_detail.html", context)


class UpDateICourse(SuccessMessageMixin, UpdateView):
    model = Course
    fields = [
        "name",
    ]

    template_name = "dashboard/instructor/icourse_update.html"
    success_url = reverse_lazy("course")
    success_message = " Course is Updated Successfully"


class DeleteICourse(SuccessMessageMixin, DeleteView):
    model = Course
    template_name = "dashboard/instructor/confirm_delete_icourse.html"
    success_url = reverse_lazy("view_courses")
    success_message = "Course Was Deleted Successfully"


# class QuizCreateView(CreateView):
#     model = Quiz
#     fields = ('name', 'course')
#     template_name = 'dashboard/instructor/quiz_add_form.html'


#     def form_valid(self, form):
#         quiz = form.save(commit=False)
#         quiz.owner = self.request.user
#         quiz.save()
#         messages.success(self.request, 'Quiz created, Go A Head And Add Questions')
#         return redirect('c', quiz.pk)


def QuizCreate(request):
    quiz_id = list(Course.objects.filter(instructor_name_id=request.user.id))
    courses = quiz_id
    context = {"courses": courses}
    return render(request, "dashboard/instructor/quiz_add_form.html", context)


def addcoursequiz(request):
    if request.method == "POST":
        name = request.POST["name"]
        course_id = request.POST["course_id"]
        course = Course.objects.filter(id=course_id).first()
        a = Quiz.objects.get_or_create(owner=request.user, name=name, course=course)
        messages.success(request, "Quiz was published successfully!")
        return redirect("add_quiz")
    else:
        messages.error(request, "Quiz was not published successfully!")
        return redirect("add_quiz")


def itutorial(request):
    tutorials = Tutorial.objects.filter(user_id=request.user.id).order_by("-created_at")
    tutorials = {"tutorials": tutorials}
    return render(request, "dashboard/instructor/list_tutorial.html", tutorials)


class QuizUpdateView(UpdateView):
    model = Quiz
    fields = ("name",)
    template_name = "dashboard/instructor/quiz_change_form.html"

    def get_context_data(self, **kwargs):
        kwargs["questions"] = self.get_object().questions.annotate(
            answers_count=Count("answers")
        )
        return super().get_context_data(**kwargs)

    def get_queryset(self):
        return self.request.user.quizzes.all()

    def get_success_url(self):
        return reverse("quiz_change", kwargs={"pk": self.object.pk})


def question_add(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk, owner=request.user)

    if request.method == "POST":
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.quiz = quiz
            question.save()
            messages.success(
                request, "You may now add answers/options to the question."
            )
            return redirect("question_change", quiz.pk, question.pk)
    else:
        form = QuestionForm()

    return render(
        request,
        "dashboard/instructor/question_add_form.html",
        {"quiz": quiz, "form": form},
    )


def question_change(request, quiz_pk, question_pk):
    quiz = get_object_or_404(Quiz, pk=quiz_pk, owner=request.user)
    question = get_object_or_404(Question, pk=question_pk, quiz=quiz)

    AnswerFormatSet = inlineformset_factory(
        Question,
        Answer,
        formset=BaseAnswerInlineFormSet,
        fields=("text", "is_correct"),
        min_num=2,
        validate_min=True,
        max_num=10,
        validate_max=True,
    )

    if request.method == "POST":
        form = QuestionForm(request.POST, instance=question)
        formset = AnswerFormatSet(request.POST, instance=question)
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                formset.save()
                formset.save()
            messages.success(request, "Question And Answers Saved Successfully")
            return redirect("quiz_change", quiz.pk)
    else:
        form = QuestionForm(instance=question)
        formset = AnswerFormatSet(instance=question)
    return render(
        request,
        "dashboard/instructor/question_change_form.html",
        {"quiz": quiz, "question": question, "form": form, "formset": formset},
    )


class QuizListView(ListView):
    model = Quiz
    ordering = ("name",)
    context_object_name = "quizzes"
    template_name = "dashboard/instructor/quiz_change_list.html"

    def get_queryset(self):
        queryset = (
            self.request.user.quizzes.select_related("course")
            .annotate(questions_count=Count("questions", distinct=True))
            .annotate(taken_count=Count("taken_quizzes", distinct=True))
        )
        return queryset


class QuestionDeleteView(DeleteView):
    model = Question
    context_object_name = "question"
    template_name = "dashboard/instructor/question_delete_confirm.html"
    pk_url_kwarg = "question_pk"

    def get_context_data(self, **kwargs):
        question = self.get_object()
        kwargs["quiz"] = question.quiz
        return super().get_context_data(**kwargs)

    def delete(self, request, *args, **kwargs):
        question = self.get_object()
        messages.success(request, "The Question Was Deleted Successfully")
        return super().delete(request, *args, **kwargs)

    def get_queryset(self):
        return Question.objects.filter(quiz__owner=self.request.user)

    def get_success_url(self):
        question = self.get_object()
        return reverse("quiz_change", kwargs={"pk": question.quiz_id})


class QuizResultsView(DeleteView):
    model = Quiz
    context_object_name = "quiz"
    template_name = "dashboard/instructor/quiz_results.html"

    def get_context_data(self, **kwargs):
        quiz = self.get_object()
        taken_quizzes = quiz.taken_quizzes.select_related("learner__user").order_by(
            "-date"
        )
        total_taken_quizzes = taken_quizzes.count()
        quiz_score = quiz.taken_quizzes.aggregate(average_score=Avg("score"))
        extra_context = {
            "taken_quizzes": taken_quizzes,
            "total_taken_quizzes": total_taken_quizzes,
            "quiz_score": quiz_score,
        }

        kwargs.update(extra_context)
        return super().get_context_data(**kwargs)

    def get_queryset(self):
        return self.request.user.quizzes.all()


class CreatePost(CreateView):
    form_class = PostForm
    model = Announcement
    template_name = "dashboard/instructor/post_form.html"
    success_url = reverse_lazy("llchat")

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.user = self.request.user
        self.object.save()
        return super().form_valid(form)


class TiseList(LoginRequiredMixin, ListView):
    model = Announcement
    template_name = "dashboard/instructor/tise_list.html"

    def get_queryset(self):
        return Announcement.objects.filter(user=self.request.user,posted_at__lt=timezone.now()).order_by(
            "posted_at"
        )


def user_profile(request):
    current_user = request.user
    user_id = current_user.id
    users = Profile.objects.filter(user_id=user_id)
    users = {"users": users}
    return render(request, "dashboard/instructor/user_profile.html", users)


def create_profile(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        phonenumber = request.POST["phonenumber"]
        bio = request.POST["bio"]
        city = request.POST["city"]
        country = request.POST["country"]
        birth_date = request.POST["birth_date"]
        avatar = request.FILES["avatar"]
        current_user = request.user
        user_id = current_user.id

        Profile.objects.filter(id=user_id).create(
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            phonenumber=phonenumber,
            bio=bio,
            city=city,
            country=country,
            birth_date=birth_date,
            avatar=avatar,
        )
        messages.success(request, "Profile was created successfully")
        return redirect("user_profile")
    else:
        current_user = request.user
        user_id = current_user.id
        users = Profile.objects.filter(user_id=user_id)
        users = {"users": users}
        return render(request, "dashboard/instructor/create_profile.html", users)


def tutorial(request):
    tutorial_id = list(Course.objects.filter(instructor_name_id=request.user.id))
    courses = tutorial_id
    context = {"courses": courses}

    return render(request, "dashboard/instructor/tutorial.html", context)


def publish_tutorial(request):
    if request.method == "POST":
        title = request.POST["title"]
        course_id = request.POST["course_id"]
        content = request.POST["content"]
        thumb = request.FILES["thumb"]
        current_user = request.user
        author_id = current_user.id
        a = Tutorial(
            title=title,
            content=content,
            thumb=thumb,
            user_id=author_id,
            course_id=course_id,
        )
        a.save()
        messages.success(request, "Tutorial was published successfully!")
        return redirect("tutorial")
    else:
        messages.error(request, "Tutorial was not published successfully!")
        return redirect("tutorial")



class ITutorialDetail(LoginRequiredMixin, DetailView):
    model = Tutorial
    template_name = "dashboard/instructor/tutorial_detail.html"



class LNotesList(ListView):
    model = Notes
    template_name = "dashboard/instructor/list_notes.html"
    context_object_name = "notes"
    paginate_by = 4

    def get_queryset(self):
        queryset = (self.request.user.notes.select_related("course"))
        return queryset


def iadd_notes(request):
    notes_id = list(Course.objects.filter(instructor_name_id=request.user.id))
    courses = notes_id
    context = {"courses": courses}
    return render(request, "dashboard/instructor/add_notes.html", context)


def publish_notes(request):
    if request.method == "POST":
        title = request.POST["title"]
        course_id = request.POST["course_id"]
        cover = request.FILES["cover"]
        video = request.FILES["video"]
        file = request.FILES["file"]
        current_user = request.user
        user_id = current_user.id

        a = Notes(
            title=title,
            cover=cover,
            video=video,
            file=file,
            user_id=user_id,
            course_id=course_id,
        )
        a.save()
        messages.success = (request, "Notes Was Published Successfully")
        return redirect("lnotes")
    else:
        messages.error = (request, "Notes Was Not Published Successfully")
        return redirect("iadd_notes")


def update_file(request, pk):
    if request.method == "POST":
        file = request.FILES["file"]
        file_name = request.FILES["file"].name

        fs = FileSystemStorage()
        file = fs.save(file.name, file)
        fileurl = fs.url(file)
        file = file_name

        Notes.objects.filter(id=pk).update(file=file)
        messages.success = (request, "Notes was updated successfully!")
        return redirect("lnotes")
    else:
        return render(request, "dashboard/instructor/update.html")


class delete_notes(SuccessMessageMixin, DeleteView):
    model = Notes
    template_name = "dashboard/instructor/confirm_delete_notes.html"
    success_url = reverse_lazy("lnotes")
    success_message = "User Was Deleted Successfully"


class UpDateTutorial(SuccessMessageMixin, UpdateView):
    model = Tutorial
    fields = [
        "title",
        "content",
        "thumb",
    ]

    template_name = "dashboard/instructor/itutorial_update.html"
    success_url = reverse_lazy("itutorial")
    success_message = " Tutorial is Updated Successfully"


class delete_tutorial(SuccessMessageMixin, DeleteView):
    model = Tutorial
    template_name = "dashboard/instructor/confirm_delete_tutorial.html"
    success_url = reverse_lazy("itutorial")
    success_message = "User Was Deleted Successfully"


class deletequiz(SuccessMessageMixin, DeleteView):
    model = Quiz
    template_name = "dashboard/instructor/confirm_delete_quiz.html"
    success_url = reverse_lazy("add_quiz")
    success_message = "User Was Deleted Successfully"


# Learner Views


def home_learner(request):
    learner = User.objects.filter(is_learner=True).count()
    instructor = User.objects.filter(is_instructor=True).count()
    course = Course.objects.all().count()
    users = User.objects.all().count()
    labels = []
    data = []

    # queryset = list(Enrollment.objects.all().values_list('coursename_id',flat=True))
    # querysettwo = list(Enrollment.objects.all().values_list('student_id',flat=True))
    queryset = (Enrollment.objects.all().values_list("coursename_id")).distinct()
    querysettwo = list(
        Enrollment.objects.values("coursename_id")
        .order_by("coursename_id")
        .annotate(count=Count("coursename_id"))
    )

    for course_count in querysettwo:
        counted_course = course_count["count"]
        data.append(counted_course)

    # for i in queryset:
    #     for p in i:
    #         x= Course.objects.filter(id=p)
    #         for z in x:
    #             labels.append(z.name)

    course_labels = Course.objects.all()
    for i in course_labels:
        labels.append(i.name)

    context = {
        "learner": learner,
        "course": course,
        "instructor": instructor,
        "users": users,
        "labels": labels,
        "data": data,
    }

    return render(request, "dashboard/learner/home.html", context)


class LearnerSignUpView(CreateView):
    model = User
    form_class = LearnerSignUpForm
    template_name = "signup_form.html"

    def get_context_data(self, **kwargs):
        kwargs["user_type"] = "learner"
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        # return redirect('learner')
        return redirect("home")


def ltutorial(request):
    tutorial_course_id = list(
        Enrollment.objects.filter(student_id=request.user.id).values_list(
            "coursename_id", flat=True
        )
    )
    result_list = []
    for i in tutorial_course_id:
        x = Tutorial.objects.filter(course_id=i)
        result_list.append(x)

    context = {"data": result_list}
    return render(request, "dashboard/learner/list_tutorial.html", context)


# class LLNotesList(ListView):
#     model = Notes
#     template_name = 'dashboard/learner/list_notes.html'
#     context_object_name = 'notes'
#     paginate_by = 4


#     def get_queryset(self):
#         return Notes.objects.order_by('-id')


class ITiseList(LoginRequiredMixin, ListView):
    model = Announcement
    template_name = "dashboard/learner/tise_list.html"

    def get_queryset(self):
        return Announcement.objects.filter(posted_at__lt=timezone.now()).order_by(
            "posted_at"
        )


def luser_profile(request):
    current_user = request.user
    user_id = current_user.id
    users = Profile.objects.filter(user_id=user_id)
    users = {"users": users}
    return render(request, "dashboard/learner/user_profile.html", users)


def lcreate_profile(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        phonenumber = request.POST["phonenumber"]
        bio = request.POST["bio"]
        city = request.POST["city"]
        country = request.POST["country"]
        birth_date = request.POST["birth_date"]
        avatar = request.FILES["avatar"]
        current_user = request.user
        user_id = current_user.id

        Profile.objects.filter(id=user_id).create(
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            phonenumber=phonenumber,
            bio=bio,
            city=city,
            country=country,
            birth_date=birth_date,
            avatar=avatar,
        )
        messages.success(request, "Profile was created successfully")
        return redirect("luser_profile")
    else:
        current_user = request.user
        user_id = current_user.id
        users = Profile.objects.filter(user_id=user_id)
        users = {"users": users}
        return render(request, "dashboard/learner/create_profile.html", users)


class LTutorialDetail(LoginRequiredMixin, DetailView):
    model = Tutorial
    template_name = "dashboard/learner/tutorial_detail.html"


class LearnerInterestsView(UpdateView):
    model = Learner
    form_class = LearnerInterestsForm
    template_name = "dashboard/learner/interests_form.html"
    success_url = reverse_lazy("lquiz_list")

    def get_object(self):
        return self.request.user.learner

    def form_valid(self, form):
        messages.success(self.request, "Course Was Updated Successfully")
        return super().form_valid(form)


# class LQuizListView(ListView):
#     model = Quiz
#     ordering = ('name', )
#     context_object_name = 'quizzes'
#     template_name = 'dashboard/learner/quiz_list.html'

#     def get_queryset(self):
#         learner = self.request.user.learner
#         learner_interests = learner.interests.values_list('pk', flat=True)
#         taken_quizzes = learner.quizzes.values_list('pk', flat=True)
#         queryset = Quiz.objects.filter(course__in=learner_interests) \
#             .exclude(pk__in=taken_quizzes) \
#             .annotate(questions_count=Count('questions')) \
#             .filter(questions_count__gt=0)
#         return queryset


def LQuizListView(request):
    quizname_id = list(
        Enrollment.objects.filter(student_id=request.user.id).values_list(
            "coursename_id", flat=True
        )
    )
    result_list = []
    for i in quizname_id:
        x = Quiz.objects.filter(course_id=i)
        result_list.append(x)

    context = {"data": result_list}
    return render(request, "dashboard/learner/quiz_list.html", context)


class TakenQuizListView(ListView):
    model = TakenQuiz
    context_object_name = "taken_quizzes"
    template_name = "dashboard/learner/taken_quiz_list.html"

    def get_queryset(self):
        queryset = self.request.user.learner.taken_quizzes.select_related(
            "quiz", "quiz__course"
        ).order_by("quiz__name")
        return queryset


def take_quiz(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk)
    learner = request.user.learner

    if learner.quizzes.filter(pk=pk).exists():
        return render(request, "dashboard/learner/taken_quiz.html")

    total_questions = quiz.questions.count()
    unanswered_questions = learner.get_unanswered_questions(quiz)
    total_unanswered_questions = unanswered_questions.count()
    progress = 100 - round(((total_unanswered_questions - 1) / total_questions) * 100)
    question = unanswered_questions.first()

    if request.method == "POST":
        form = TakeQuizForm(question=question, data=request.POST)
        if form.is_valid():
            with transaction.atomic():
                learner_answer = form.save(commit=False)
                learner_answer.student = learner
                learner_answer.save()
                if learner.get_unanswered_questions(quiz).exists():
                    return redirect("take_quiz", pk)
                else:
                    correct_answers = learner.quiz_answers.filter(
                        answer__question__quiz=quiz, answer__is_correct=True
                    ).count()
                    score = round((correct_answers / total_questions) * 100.0, 2)
                    TakenQuiz.objects.create(learner=learner, quiz=quiz, score=score)
                    if score < 50.0:
                        messages.warning(
                            request,
                            "Better luck next time! Your score for the quiz %s was %s."
                            % (quiz.name, score),
                        )
                    else:
                        messages.success(
                            request,
                            "Congratulations! You completed the quiz %s with success! You scored %s points."
                            % (quiz.name, score),
                        )
                    return redirect("lquiz_list")
    else:
        form = TakeQuizForm(question=question)

    return render(
        request,
        "dashboard/learner/take_quiz_form.html",
        {"quiz": quiz, "question": question, "form": form, "progress": progress},
    )


class send_course(ListView):
    model = Notes
    template_name = "dashboard/instructor/send_course.html"
    context_object_name = "notes"
    paginate_by: 4

    def get_queryset(self):
        return Notes.objects.order_by("-id")


class UpDateProfile(SuccessMessageMixin, UpdateView):
    model = Profile
    fields = [
        "avatar",
        "first_name",
        "last_name",
        "email",
        "phonenumber",
        "birth_date",
        "bio",
        "city",
        "state",
        "country",
        "hobby",
    ]

    template_name = "dashboard/learner/update_profile_new.html"
    success_url = reverse_lazy("luser_profile")
    success_message = " User Profile is Updated Successfully"


class InsUpdateProfile(UpDateProfile, UpdateView):
    template_name = "dashboard/instructor/ins_update_profile_new.html"
    success_url = reverse_lazy("user_profile")
    success_message = " User Profile is Updated Successfully"


class AdminUpdateProfile(UpDateProfile, UpdateView):
    template_name = "dashboard/admin/adm_update_profile_new.html"
    success_url = reverse_lazy("auser_profile")
    success_message = " User Profile is Updated Successfully"


class LearnerCourse(LoginRequiredMixin, ListView):
    model = Course
    template_name = "dashboard/learner/learner_course.html"

    def get_queryset(self):
        return Course.objects.all()


def StudentCount(request):
    groups = Course.objects.annotate(nstud=Count("Learner"))
    context = {"groups": groups}
    return render(request, "dashboard/admin/home.html", context)


def enrolment(request, pk):
    istudent = request.user
    icourse = Course.objects.get(pk=pk)
    inotes = request.user.id
    ienrolment = Enrollment.objects.get_or_create(student=istudent, coursename=icourse)
    enrolment = Enrollment.objects.filter(student=request.user)
    context = {"enrol": enrolment}

    return render(request, "dashboard/learner/enrolment.html", context)


def LLNotesList(request):
    coursename_id = list(
        Enrollment.objects.filter(student_id=request.user.id).values_list(
            "coursename_id", flat=True
        )
        
    )
    result_list = []
    for i in coursename_id:
        x = Notes.objects.filter(course_id=i, is_approved=True)
        result_list.append(x)

    context = {"data": result_list}
    return render(request, "dashboard/learner/list_notes.html", context)


def showregcourse(request):
    user = request.user
    enrolment = Enrollment.objects.filter(student=user)
    context = {"enrol": enrolment}
    return render(request, "dashboard/learner/enrolment.html", context)


class delete_registered_course(SuccessMessageMixin, DeleteView):
    model = Enrollment
    template_name = "dashboard/learner/confirm_delete_rcourse.html"
    success_url = reverse_lazy("learner_course")
    success_message = "User Was Deleted Successfully"


def EnrollChart(request):
    queryset = Course.objects.all()
    return render(request, "dashboard/learner/home.html")



def permision(request):
    allusers = User.objects.all()
    content_type = ContentType.objects.get_for_model(Tag)
    tag_permission= Permission.objects.filter(content_type=content_type).order_by('name')
    # tag_permission = Permission.objects.filter(codename="view_admindashboard",content_type=content_type)

    context={
        'allusers':allusers,
        'allpermision':tag_permission
    }
    return render(request,'dashboard/admin/permision.html',context)



def addpermision(request):
    if request.method=='POST':
        username= request.POST['name']

        if username=='is_admin':
            user=User.objects.filter(is_admin=True)
        
        if username=='is_learner':
            user=User.objects.filter(is_learner=True)

        if username=='is_instructor':
            user=User.objects.filter(is_instructor=True)
        
        permcheckbox=request.POST.getlist('permcheckbox')
        # user = User.objects.filter(username=username)


        content_type = ContentType.objects.get_for_model(Tag)
        
        for iperm in permcheckbox:
            tag_permission=Permission.objects.filter(codename=iperm,content_type=content_type)
            for perm in tag_permission:
                for iuser in user:
                    iuser.user_permissions.add(perm)

    messages.success(request,'Permissions Given Successfully!')
    return redirect('permision')


def removepermision(request):
    allusers = User.objects.all()
    content_type = ContentType.objects.get_for_model(Tag)
    tag_permission= Permission.objects.filter(content_type=content_type).order_by('name')
    context={
        'allusers':allusers,
        'allpermision':tag_permission

        }
    return render(request,'dashboard/admin/removepermision.html',context)

def removeperm(request):
    if request.method=='POST':
        username= request.POST['name']
        if username=='is_admin':
            user=User.objects.filter(is_admin=True)
        if username=='is_learner':
            user=User.objects.filter(is_learner=True)
        if username=='is_instructor':
            user=User.objects.filter(is_instructor=True)        
        permcheckbox=request.POST.getlist('permcheckbox')
        # user = User.objects.filter(username=username)


        content_type = ContentType.objects.get_for_model(Tag)
        
        for iperm in permcheckbox:
            tag_permission=Permission.objects.filter(codename=iperm,content_type=content_type)
            for perm in tag_permission:
                for iuser in user:
                    iuser.user_permissions.remove(perm)

    # if request.method=='POST':
    #     username= request.POST['name']
    #     permcheckbox=request.POST.getlist('permcheckbox')
    #     user = User.objects.get(username=username)
    #     content_type = ContentType.objects.get_for_model(Tag)
        
    #     for iperm in permcheckbox:
    #         tag_permission=Permission.objects.filter(codename=iperm,content_type=content_type)
    #         for perm in tag_permission:
    #             user.user_permissions.remove(perm)
    messages.success(request,'Permissions Removed Successfully!')
    return redirect('removepermision')

def tag(request):
    return render(request,'dashboard/admin/tag.html')

def addtag(request):
    if request.method=='POST':
        title = request.POST['title']
        slug = request.POST['slug']
        tags = Tag.objects.get_or_create(title=title,slug=slug)
        context={'tags':tags}
    return render(request,'dashboard/admin/base.html')


def tagview(request,slug):
    tag = Tag.objects.get(slug=slug)
    return HttpResponse(f"you are on {tag.slug} page")


from django.contrib.auth.models import Permission
def viewpermision(request):
    user_admin = User.objects.filter(is_admin=True).values_list('id').first()
    user_instructor = User.objects.filter(is_instructor=True).values_list('id').first()
    user_learner = User.objects.filter(is_learner=True).values_list('id').first()

    for usr in user_admin:
        adminperm = Permission.objects.filter(user=usr)
        for perm in adminperm:
            print("admin perm",perm)
    
    for usr in user_instructor:
        instructorperm = Permission.objects.filter(user=usr)
        for perm in instructorperm:
            print("inst perm",perm)

    for usr in user_learner:
        learnerperm = Permission.objects.filter(user=usr)
        for perm in learnerperm:
            print("learner perm",perm)

    context={
        'adminperm':adminperm,
        'instructorperm':instructorperm,
        'learnerperm':learnerperm,
        }



    return render(request,'dashboard/admin/viewpermision.html',context)

# # from django.contrib.auth.decorators import permission_required
# # @permission_required("elearn.view_tag")
# def viewallowtag(request):
#     tags = Tag.objects.all()
#     context={'tags':tags}
#     return render(request,'dashboard/admin/base.html',context)


def test(request):
    all_admin = list(User.objects.filter(is_admin=True))
   
    single_user_admin = User.objects.filter(is_admin=True).values_list('id').first()

    instructorperm = Permission.objects.filter(user=single_user_admin)

    for perm in instructorperm:
        for iuser in all_admin:
            iuser.user_permissions.add(perm)
  
    return render(request, "dashboard/admin/test.html")


def removespecific(request):
    if request.method=='POST':
        permcheckbox=request.POST.getlist('permcheckbox')
        print(permcheckbox)
        content_type = ContentType.objects.get_for_model(Tag)
        user = User.objects.all()
        print(user)                
        for iperm in permcheckbox:
            tag_permission=Permission.objects.filter(codename=iperm,content_type=content_type)
            for perm in tag_permission:
                  for iuser in user:
                    iuser.user_permissions.remove(perm)
    
    messages.success(request,'Selected Specific Permissions Removed Successfully!')
    return redirect('viewpermision')


def view_all_courses(request):
    notes = Notes.objects.all()
    notes = {"notes": notes}
    return render(request, "dashboard/admin/view_all_courses.html", notes)
 
def approve_course(request, notes_id):
    notes = Notes.objects.get(id = notes_id)
    notes.is_approved = True
    notes.save()
    return redirect('viewallcourses')

def disapprove_course(request, notes_id):
    notes = Notes.objects.get(id = notes_id)
    notes.is_approved = False
    notes.save()
    return redirect('viewallcourses')
 
 

 
