from functools import wraps
from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponse

##admin decorator

#view_admindashboard
def view_admindashboard_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_admindashboard")):
            return True
    return False


def view_admindashboard_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_admindashboard_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_registerinstructor
def view_registerinstructor_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_registerinstructor")):
            return True
    return False


def view_registerinstructor_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_registerinstructor_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_registerlearner
def view_registerlearner_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_registerlearner")):
            return True
    return False


def view_registerlearner_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_registerlearner_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_registercourse
def view_registercourse_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_registercourse")):
            return True
    return False


def view_registercourse_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_registercourse_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_announcement
def view_announcement_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_announcement")):
            return True
    return False


def view_announcement_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_announcement_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator

#view_manageuser
def view_manageuser_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_manageuser")):
            return True
    return False


def view_manageuser_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_manageuser_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_manageprofile
def view_manageprofile_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_manageprofile")):
            return True
    return False


def view_manageprofile_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_manageprofile_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_dynamichome
def view_dynamichome_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_dynamichome")):
            return True
    return False


def view_dynamichome_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_dynamichome_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator

#view_dynamicaboutus
def view_dynamicaboutus_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_dynamicaboutus")):
            return True
    return False


def view_dynamicaboutus_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_dynamicaboutus_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_dynamiccontactus
def view_dynamiccontactus_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_dynamiccontactus")):
            return True
    return False


def view_dynamiccontactus_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_dynamiccontactus_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_createrole
def view_createrole_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_createrole")):
            return True
    return False


def view_createrole_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_createrole_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_addtag
def view_addtag_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_addtag")):
            return True
    return False


def view_addtag_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_addtag_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_addpermision
def view_addpermision_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_addpermision")):
            return True
    return False


def view_addpermision_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_addpermision_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator


#view_removepermision
def view_removepermision_test_function(user):
    if user.is_admin:
        if (user.has_perm("elearn.view_removepermision")):
            return True
    return False


def view_removepermision_access_only():
    def decorator(view):
        @wraps(view)
        def _wrapped_view(request, *args, **kwargs):
            if not view_removepermision_test_function(request.user):
                return HttpResponse("You are not a Admin and you are not allowed to access this page !")
            return view(request, *args, **kwargs)
        return _wrapped_view
    return decorator